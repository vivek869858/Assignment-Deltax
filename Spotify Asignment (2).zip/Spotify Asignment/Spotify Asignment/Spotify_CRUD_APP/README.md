# Spotify_CRUD_APP


### It is the  spotify like web applicaton developed in MERN STACK . I have added some  features like add songs , add artists and add ratings by users. Also I have dockerized the whole application.





## This is the signup and login page


![Screenshot (83)](https://user-images.githubusercontent.com/71813414/177187345-a6f8466c-9f41-4ddd-870e-52b957b767ad.png)
![Screenshot (82)](https://user-images.githubusercontent.com/71813414/177187352-03b1f4f4-05a3-4b28-84e2-7d649397d132.png)

## You must have to login before go to home or artist page

![Screenshot (77)](https://user-images.githubusercontent.com/71813414/177187563-b16358a4-b767-4258-85e9-4057daef9ea5.png)
![Screenshot (78)](https://user-images.githubusercontent.com/71813414/177187574-17b2bc1d-f294-4f97-9fd6-0dbd95b47aa8.png)

## As you can see this is home page and there is Add Song button and it is visible  only for Admin user so that admin can add songs and artist  

![Screenshot (79)](https://user-images.githubusercontent.com/71813414/177188213-52fc3925-c8f9-49d0-9be2-35ba1040efc4.png)
![Screenshot (80)](https://user-images.githubusercontent.com/71813414/177188224-5bd3a173-a622-4212-8b8c-ca99aafab6f2.png)

## If there is no artist to select you can add artist in the add song component using modals


![Screenshot (81)](https://user-images.githubusercontent.com/71813414/177188494-b753b452-d6fa-4201-bef6-e8c2a4da3ee9.png)

## You can also view the artist and add artist in the view artist page


## If the user is normal user he can only give the ratings and he won't be able to perform any CRUD Operation


![Screenshot (85)](https://user-images.githubusercontent.com/71813414/177188841-5d023a45-4eed-4cd7-95b4-975a59d38c2e.png)
